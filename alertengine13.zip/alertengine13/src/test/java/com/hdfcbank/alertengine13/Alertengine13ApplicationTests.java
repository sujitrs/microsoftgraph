package com.hdfcbank.alertengine13;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Alertengine13ApplicationTests {

	@Test
	void contextLoads() {
	}

}
