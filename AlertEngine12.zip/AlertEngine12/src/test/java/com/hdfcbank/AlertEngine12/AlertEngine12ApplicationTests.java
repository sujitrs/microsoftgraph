package com.hdfcbank.AlertEngine12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlertEngine12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
