package com.hdfcbank.AlertEngine12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlertEngine12Application {

	public static void main(String[] args) {
		SpringApplication.run(AlertEngine12Application.class, args);
	}

}
