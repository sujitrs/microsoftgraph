package com.hdfcbank.alertengine13;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Alertengine13Application {

	public static void main(String[] args) {
		SpringApplication.run(Alertengine13Application.class, args);
	}

}
